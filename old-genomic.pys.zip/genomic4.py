import sc, random, contextlib, wave, os, math
import shlex, subprocess, signal
import NRTOSCParser3

import numpy as np
import scipy.signal


# generator class for weighted random numbers
#
# Pass in one or the other:
# - weights: custom weights array
# - size: size of "standard" weights array that algo should make on its own
#
# call next to actually make the random selection
#
class WeightedRandomGenerator(object):
	"""
	mu - should be 0!
	stdev - set very lo (at most 1/4 of the desired range)

	"""
	def __init__(self, mn=0.0, stdev=1.0, lo=0.0, hi=1.0, initval=0):
		self.mean = mn
		self.stdev = stdev
		self.lo = lo
		self.hi = hi
		self.val = initval
		
	def next(self, scale=1.0):
		rnd = random.gauss(self.mean, self.stdev)
		self.val = min(max((self.val+rnd), self.lo), self.hi)
		return self.val

	def __call__(self): return self.next()


# helper function
def midi2hz(m): return pow(2.0, (m/12.0))

ALPHA = 0
C_DELAY = 1
BETA = 2
D_MULT = 3
GAMMA = 4
MS_BINS = 5

class GenomicExplorer:

	def __init__(self, anchor, sfilename, size=10, start_state=[1.0, 0.0, 1.0, 1.0, 1.0, 0.0]):
				
		self.anchor = anchor
		self.sfpath = anchor + '/snd/' + sfilename
		self.filename = sfilename
		
		with contextlib.closing(wave.open(self.sfpath,'r')) as f: 
			self.frames = f.getnframes()
			self.rate = f.getframerate()
			self.dur = self.frames/float(self.rate)
		
		self.mutation_prob = 0.01
		self.filter_mutation_prob = 0.01
		self.depth = 25
 		# 'alpha', 'c_delay', 'beta', 'd_mult', 'gamma', 'ms_bins'
		self.parser = NRTOSCParser3.NRTOSCParser3(anchor=self.anchor)
		self.rawtable, self.rawmaps, self.dists = dict(), dict(), dict()

		self.init_population(size=size, starter=start_state)

	
	def init_population(self, size, starter=None):
		self.population = []
		self.filter_population = []
		for n in range(size):
  			start = [random.randrange(500, 1000)*0.001, random.randrange(0,50)*0.001, random.randrange(500, 1000)*0.001, random.randrange(100,1000)*0.01, random.randrange(500, 1000)*0.001, random.randrange(0,5000)*0.01]
 			self.population += [Genome(start)]
# 			self.population += [Genome(starter)]
			self.filter_population += [FilterMapper()]
		self.population[0] = Genome(starter)
		self.filter_population[0] = FilterMapper(id=True)
		self.analyze_individual(0)
		self.activate_raw_data(0)
		self.compare_all_individuals(aflag=True)
			
	def mutate(self):
		
		if random.random() < self.mutation_prob:
			indiv = random.randint(1, len(self.population)-1)
			self.population[ indiv ].mutate()
			self.population[ indiv ].edits += 1
			self.analyze_individual( indiv )
			self.activate_raw_data( indiv )
# 			self.compare_individual_chi_squared( indiv )
			self.compare_individual( indiv )
		if random.random() < self.filter_mutation_prob:
			indiv = random.randint(1, len(self.filter_population)-1)
			self.filter_population[ indiv ].mutate()
			self.filter_population[ indiv ].edits += 1
			self.analyze_individual( indiv )
			self.activate_raw_data( indiv )
			self.compare_individual( indiv )
	
	def mate(self, a, b, kill_index):
		
		cut = random.randint(0,5)
		offspring = None
		
		if random.random() < 0.5:
			offspring = self.population[a].values[:]
		else:
			offspring = self.population[b].values[:]
		
		# basic gene selection from 2 parents
		for i in range(6):	
			if random.random() < 0.5:
				offspring[i] = self.population[a].values[i]
			else:
				offspring[i] = self.population[b].values[i]
		
		self.population[kill_index] = Genome(offspring)
		
		self.analyze_individual(kill_index)
		self.activate_raw_data(kill_index)
# 		self.compare_individual_chi_squared( indiv )
		self.compare_individual(kill_index)

	def mate_filters(self, a, b, kill_index):
		
		cut = random.randint(0,25)
		offspring = None
		
		if random.random() < 0.5:
			offspring = self.filter_population[a].values[:]
		else:
			offspring = self.filter_population[b].values[:]
		
		# basic gene selection from 2 parents
		for i in range(25):	
			if random.random() < 0.5:
				offspring[i] = self.filter_population[a].values[i]
			else:
				offspring[i] = self.filter_population[b].values[i]
		
		self.filter_population[kill_index] = FilterMapper(offspring)
		
		self.analyze_individual(kill_index)
		self.activate_raw_data(kill_index)
		self.compare_individual(kill_index)
	
	def sort_by_distances(self, depth):
		sorted_dists = [[k, self.dists[k], self.population[k].age, self.population[k].edits] for k in sorted(self.dists.keys())]
		sorted_dists = sorted(sorted_dists[1:], key = lambda row: row[1]) # + (maxedits - row[3])))
		return sorted_dists[:depth], sorted_dists[(-1*depth):]
	
	
	def reproduce(self, depth=25):
		
		kills, duplicates = self.sort_by_distances(depth)
		
		# depth # of times: choose 2 random parents to mate and overwrite replacement in unfit individual's slot
		for n in range(depth):
			
			aidx = duplicates[ random.randint(0, depth-1) ][0]
			bidx = duplicates[ random.randint(0, depth-1) ][0]

			kidx = kills[ random.randint(0, depth-1) ][0]
			
			self.mate(aidx, bidx, kidx)

			cidx = duplicates[ random.randint(0, depth-1) ][0]
			didx = duplicates[ random.randint(0, depth-1) ][0]

			k2idx = kills[ random.randint(0, depth-1) ][0]
			
			self.mate_filters(cidx, didx, k2idx)
	
	def age_pop(self):
		for i in range(len(self.population)): self.population[i].age += 1
	
	def iterate(self, iters=1):
		sc.quit()
		for iter in range(iters):
			self.age_pop()
			self.mutate()
			if (iter%20)==0:
				print self.population[0].age
				self.reproduce(self.depth)
				self.print_all_dists()
	
	def print_all_individuals(self):
		print '== pop ==========================='
		for g in self.population: print g
	
	def start_sc(self):
		sc.start()
 		self.bnum = sc.loadSnd(self.sfpath, wait=False)
	


class FilterMapper:
	
	def __init__(self, id=False):
		if id is True:
			self.values = np.ones(25)
		else:
			self.values = np.array([float(random.randint(0,1)) for i in range(25)], dtype='float32')
		self.age = 0
		self.edits = 0
		
	def __repr__(self):
		return str([val for val in self.values])
	
	def mutate(self):
		choice = random.randint(0, 24)
		self.values[choice] = 1.0 - self.values[choice]
	

class Genome:

	def __init__(self, starter):

		print 'starter: ', starter
		
		self.values = [starter[ALPHA], starter[C_DELAY], starter[BETA], starter[D_MULT], starter[GAMMA], starter[MS_BINS]]
		self.tratio	= 1.0		# in Hertz!!!
		
		self.generators = [
			WeightedRandomGenerator(0.0, 	0.1, 	0.5,	1.0,	self.values[ALPHA]),
			WeightedRandomGenerator(0.0, 	0.0025,	0.0, 	0.05,	self.values[C_DELAY]),
			WeightedRandomGenerator(0.0, 	0.05, 	0.5,	1.0,	self.values[BETA]),
			WeightedRandomGenerator(0.0, 	0.5, 	1.0,	10.,	self.values[D_MULT]),
			WeightedRandomGenerator(0.0, 	0.05, 	0.5,	1.0,	self.values[GAMMA]),
			WeightedRandomGenerator(0.0, 	2.5, 	0.0,	50.,	self.values[MS_BINS])
		]
		self.age = 0
		self.edits = 0
	
	def __repr__(self):
		return "%9i/%9i || %.6f|%.6f|%.6f|%.6f|%.6f|%.6f" % (self.age, self.edits, self.values[ALPHA], self.values[C_DELAY], self.values[BETA], self.values[D_MULT], self.values[GAMMA], self.values[MS_BINS])
	
	def mutate(self):
		choice = random.randint(0,5)

		self.values[choice] = self.generators[choice].next()
	

# if __name__=='__main__':
# 	genex = GenomicExplorer('/Users/kfl/dev/python/sc-0.3.1/genomic', 'test.wav')
# 	genex.analyze_genome(1)